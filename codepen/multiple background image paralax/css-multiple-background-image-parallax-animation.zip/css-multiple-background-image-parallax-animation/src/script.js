// that's one steeep cliff face
// in episode 3 of jojo's bizarre adventure, there's this really short scene when jojo arrives at london and the city is introduced in a similar way. 
// This method is pretty common in many animated shows. 
// I got lazy and stopped making my own art assets and put this together with images found from around the web -_-