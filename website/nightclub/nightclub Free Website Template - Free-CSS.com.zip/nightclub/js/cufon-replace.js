Cufon.replace('#menu a, h2, .dropcap_1, h3, h4, .phone span, #ContactForm .button', { fontFamily: 'NewsGoth BT', hover:true });

